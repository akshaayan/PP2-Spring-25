Python Open Project - battleship
===========================

This is a project powered by Codecademy students.

Project 1: Battleship

For this project we'll be using the pygame framework wich is basically
a module made for making python games for windows/mac/linux/etc.

If you're not related to the pygame framework, here are some tutorials:
<ul>
  <li><a href="http://www.pygame.org/wiki/tutorials">pygame page tutorials</a>
  <li><a href="http://inventwithpython.com/pygame/chapters/">invent with python</a></li>
</ul>
