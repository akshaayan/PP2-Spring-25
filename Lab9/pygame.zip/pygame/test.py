from random import randint
import pygame
from pygame.math import Vector2

pygame.init()
pygame.font.init()

screen = pygame.display.set_mode((600, 600))
screen_width = 600
screen_height = 600
black = (0, 0, 0)
white = (255, 255, 255)
pygame.display.set_caption("gang")
clock = pygame.time.Clock()


class Player(pygame.sprite.Sprite):

    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface((50, 30), pygame.SRCALPHA)
        pygame.draw.polygon(self.image, pygame.Color('steelblue2'), [(0, 0), (50, 15), (0, 30)])
        self.original_image = self.image
        self.rect = self.image.get_rect(center=pos)
        self.pos = Vector2(pos)
        self.velocityx = Vector2(6, 0)
        self.velocityy = Vector2(0, 6)
        self.angle = 0

    def update(self):
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        clamp_rect = self.rect.clamp(screen.get_rect())
        if clamp_rect != self.rect:
            self.rect = clamp_rect
            self.pos.x, self.pos.y = self.rect.center
        self.rotate()

    def rotate(self):
        direction = pygame.mouse.get_pos() - self.pos
        self.radius, self.angle = direction.as_polar()
        self.image = pygame.transform.rotate(self.original_image, -self.angle)
        self.rect = self.image.get_rect(center=self.rect.center)


class EnemyX(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill((randint(0, 255), randint(0, 255), randint(0, 255)))
        self.rect = self.image.get_rect()
        self.pos = Vector2(randint(-500, 0), randint(50, 550))
        self.velocity = Vector2(3, 0)

    def update(self):
        self.pos += self.velocity
        self.rect.center = self.pos
        if Vector2.length(self.pos) > Vector2.length(Vector2(800, 0)):
            self.pos = Vector2(randint(-500, 0), randint(50, 550))


class EnemyY(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill((randint(0, 255), randint(0, 255), randint(0, 255)))
        self.rect = self.image.get_rect()
        self.pos = Vector2(randint(50, 550), randint(-500, 0))
        self.velocity = Vector2(0, 3)

    def update(self):
        self.pos += self.velocity
        self.rect.center = self.pos
        if Vector2.length(self.pos) > Vector2.length(Vector2(800, 0)):
            self.pos = Vector2(randint(50, 550), randint(-500, 0))


class Bullet(pygame.sprite.Sprite):
    def __init__(self, pos, angle):
        super().__init__()
        self.image = pygame.Surface((50, 30), pygame.SRCALPHA)
        pygame.draw.circle(self.image, (255, 255, 255), (25, 15), 4)
        self.original_image = self.image
        self.rect = self.image.get_rect(center=pos)
        self.pos = Vector2(pos)
        self.velocity = Vector2(9, 0).rotate(angle)
        self.angle = 0

    def update(self):
        self.pos += self.velocity
        self.rect.center = self.pos
        clamp_rect = self.rect.clamp(screen.get_rect())
        if clamp_rect != self.rect:
            self.rect.clamp_ip(screen.get_rect())
            if screen.get_rect().contains(self.rect):
                self.kill()

    def rotate(self):
        direction = pygame.mouse.get_pos() - self.pos
        self.radius, self.angle = direction.as_polar()
        self.image = pygame.transform.rotate(self.original_image, -self.angle)
        self.rect = self.image.get_rect(center=self.rect.center)


def xor(a, b):
    if bool(a) != bool(b):
        return True
    else:
        return False

def score_display(surface, text, size, x, y):
    font = pygame.font.Font(size=size)
    text_surface = font.render(text, True, white)
    text_rect = text_surface.get_rect()
    text_rect.topleft = (x, y)
    surface.blit(text_surface, text_rect)


player = Player((300, 300))
bullets = pygame.sprite.Group()
enemies_listX = pygame.sprite.Group()
enemies_listY = pygame.sprite.Group()
all_sprites = pygame.sprite.Group(player)

for i in range(5):  # number of enemies spawned (x)
    enemyX = EnemyX()
    # enemyX.velocity = Vector2(15, 2)
    enemies_listX.add(enemyX)
    all_sprites.add(enemyX)
for i in range(5):  # number of enemies spawned (y)
    enemyY = EnemyY()
    enemies_listY.add(enemyY)
    all_sprites.add(enemyY)


def drawing_text(surface, text, size, x, y):
    font = pygame.font.Font(size=size)
    text_surface = font.render(text, False, white)
    text_rect = text_surface.get_rect()
    text_rect.center = (x, y)
    surface.blit(text_surface, text_rect)


def main():
    screen_rect = screen.get_rect()
    score = 0

    drawing_text(screen, "Welcome to the game!", 32, 300, 150)
    drawing_text(screen, "Press any key to start", 32, 300, 300)
    pygame.display.flip()

    run = True
    waiting = True

    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False
                run = False
            if event.type == pygame.KEYUP:
                waiting = False

    while run:
        clock.tick(60)

        keys = pygame.key.get_pressed()

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                quit()
                run = False

        if keys[pygame.K_SPACE]:
            if len(bullets) < 1:  # number of bullets on screen
                projectile = Bullet(player.pos, player.angle)
                bullets.add(projectile)
                all_sprites.add(projectile)
        if xor(keys[pygame.K_a], keys[pygame.K_k]):
            player.pos -= player.velocityx
        elif xor(keys[pygame.K_d], keys[pygame.K_SEMICOLON]):
            player.pos += player.velocityx
        elif xor(keys[pygame.K_w], keys[pygame.K_o]):
            player.pos -= player.velocityy
        elif xor(keys[pygame.K_s], keys[pygame.K_l]):
            player.pos += player.velocityy

        player.rect.clamp_ip(screen_rect)

        collide_list_x = pygame.sprite.spritecollide(player, enemies_listX, False)
        collide_list_y = pygame.sprite.spritecollide(player, enemies_listY, False)
        if collide_list_x or collide_list_y:
            player.kill()
            game_over = True
            pygame.display.flip()
            screen.fill((160, 100, 10))
            drawing_text(screen, "Game Over",32, 300, 150)
            drawing_text(screen, "Score: " + str(score), 32, 300, 300)
            drawing_text(screen, "Press any key to restart", 32, 300, 450)
            
        # if game_over:
        # end_text = .render('Game Over!', True, 'black')
        # end_text2 = font.render('Game Over: Press Enter to Restart', True, 'black')
        # screen.blit(end_text, (70, 20))
        # screen.blit(end_text2, (60, 80))
        # player_y = - 300
        # y_speed = 0

        bullet_collide_x = pygame.sprite.groupcollide(bullets, enemies_listX, True, True)
        if bullet_collide_x:
            for collisions in bullet_collide_x:
                enemyX = EnemyX()
                enemies_listX.add(enemyX)
                all_sprites.add(enemyX)
                score += 1
                if score > 5: 
                    enemyX.velocity = Vector2(speed_x, 5)
                    speed_x=speed_x+10

        bullet_collide_y = pygame.sprite.groupcollide(bullets, enemies_listY, True, True)
        if bullet_collide_y:
            for collisions_y in bullet_collide_y:
                enemyY = EnemyY()
                enemies_listY.add(enemyY)
                all_sprites.add(enemyY)
                score += 1

        screen.fill((30, 30, 30))
        all_sprites.update()
        all_sprites.draw(screen)
        bullets.update()
        bullets.draw(screen)
        score_display(screen, "Score: " + str(score), 18, 0, 0)
        pygame.display.update()


main()